package com.example.cqu.homework;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText m_EDAccount;
    private EditText m_EDPeople;
    private TextView m_TVshow;
    private Button m_BtnOk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m_EDAccount= (EditText) findViewById(R.id.ETMoney);
        m_EDPeople=(EditText)findViewById(R.id.ETPeople);
        m_TVshow=(TextView)findViewById(R.id.TVShow);
        m_BtnOk=(Button)findViewById(R.id.BtnCacu);
        m_BtnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int money;
                int people;
                String text=m_EDAccount.getText().toString();
                String text2=m_EDPeople.getText().toString();
                money=Integer.parseInt(m_EDAccount.getText().toString());
                people=Integer.parseInt(m_EDPeople.getText().toString());
                int pay=0;
                if(people==0)
                    m_TVshow.setText("please input the number of people");
                else {
                    pay=money/people;
                    text=Integer.toString(pay);
                    m_TVshow.setText(text);
                }
            }
        });

    }
}
